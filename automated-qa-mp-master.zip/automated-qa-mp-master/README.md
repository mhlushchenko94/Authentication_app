# Automated-Tests

JavaScript project for test automation, covering UI acceptance testing of the Flexshopper website.

## Concepts Included
* Page Object pattern
* Dependency injection
* Webdriver protocol commands

## Tools
* Selenium Webdriver
* WebdriverIO
* Mocha Framework
* Chai assertions

## Requirements

1. Install JDK

    https://www.oracle.com/technetwork/java/javase/downloads/index.html

1. Install Eslint
    ```
    yarn global add eslint
    ```

## Getting Started

1. Clone this repository
    ```sh
    git clone git@github.com:FlexShopper/automated-qa-mp.git
    ```

1. Setup environment variables
    ```sh
    cp .envrc.example .envrc
    ```

1. Install dependencies
    ```sh
    yarn
    ```

1. Available test commands:

    - e2e sweep lease
    ```sh
    yarn sweep
    ```
    
    - e2e sweep loan
    ```sh
    yarn sweep_loan
    ```

## Local Run

Comment out if (process.env.USE_SELENIUM_HUB) function in wdio.conf.js file
