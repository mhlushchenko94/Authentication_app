---
name: New Feature Suggestion
about: Request a new feature for Homebrew/brew

---

Please replace this section with:
- a detailed description of your proposed feature
- the motivation for the feature
- how the feature would be relevant to at least 90% of Homebrew users (if it's not: do not open a feature request)
- what alternatives to the feature you have considered

We will close this issue or ask you to create a pull-request if it's something the maintainers are not actively planning to work on.
