class BottleSpecification
  def skip_relocation?
    false
  end
end
