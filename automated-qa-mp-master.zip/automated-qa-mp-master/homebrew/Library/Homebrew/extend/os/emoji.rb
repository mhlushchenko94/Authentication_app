require "extend/os/mac/emoji" if OS.mac?
