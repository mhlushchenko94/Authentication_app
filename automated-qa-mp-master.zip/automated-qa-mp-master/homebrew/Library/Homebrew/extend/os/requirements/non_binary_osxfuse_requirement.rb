if OS.mac?
  require "extend/os/mac/requirements/non_binary_osxfuse_requirement"
end
