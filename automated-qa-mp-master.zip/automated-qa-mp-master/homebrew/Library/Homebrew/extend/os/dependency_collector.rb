require "extend/os/mac/dependency_collector" if OS.mac?
