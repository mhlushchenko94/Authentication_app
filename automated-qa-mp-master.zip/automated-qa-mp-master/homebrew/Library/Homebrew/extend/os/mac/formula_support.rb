class KegOnlyReason
  def valid?
    true
  end
end
