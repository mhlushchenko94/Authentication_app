PYTHON_VIRTUALENV_URL =
  "https://files.pythonhosted.org/packages/33/bc" \
  "/fa0b5347139cd9564f0d44ebd2b147ac97c36b2403943dbee8a25fd74012" \
  "/virtualenv-16.0.0.tar.gz".freeze
PYTHON_VIRTUALENV_SHA256 =
  "ca07b4c0b54e14a91af9f34d0919790b016923d157afda5efdde55c96718f752".freeze
