require "requirement"

class NonBinaryOsxfuseRequirement < Requirement
  fatal false
end

require "extend/os/requirements/non_binary_osxfuse_requirement"
