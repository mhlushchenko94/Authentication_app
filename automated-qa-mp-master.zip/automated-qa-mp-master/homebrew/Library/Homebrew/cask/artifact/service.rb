require "cask/artifact/moved"

module Cask
  module Artifact
    class Service < Moved
    end
  end
end
