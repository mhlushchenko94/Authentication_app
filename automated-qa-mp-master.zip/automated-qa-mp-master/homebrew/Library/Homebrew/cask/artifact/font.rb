require "cask/artifact/moved"

module Cask
  module Artifact
    class Font < Moved
    end
  end
end
