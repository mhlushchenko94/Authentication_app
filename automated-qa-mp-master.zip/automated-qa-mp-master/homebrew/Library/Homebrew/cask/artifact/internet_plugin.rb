require "cask/artifact/moved"

module Cask
  module Artifact
    class InternetPlugin < Moved
    end
  end
end
