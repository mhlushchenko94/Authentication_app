require "cask/artifact/moved"

module Cask
  module Artifact
    class VstPlugin < Moved
    end
  end
end
