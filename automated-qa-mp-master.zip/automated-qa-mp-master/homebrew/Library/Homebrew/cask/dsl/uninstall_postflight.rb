module Cask
  class DSL
    class UninstallPostflight < Base
    end
  end
end
